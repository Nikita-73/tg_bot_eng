from aiogram import types

def text_filter(message: types.Message):
    return True  # Простой фильтр, разрешает все сообщения
