from aiogram import types
from utils.keyboards import start_keyboard
from config import *
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.filters.command import Command


# Хэндлер на команду /start
@dp.message(Command("start"))
async def cmd_start(message: types.Message):
    builder = InlineKeyboardBuilder()
    builder.add(
        types.InlineKeyboardButton(text="Далее", callback_data="Greetings_0")
    )
    await message.answer(
        """Приветствуем тебя в Simleword! 🎉 
Наш бот помогает изучать английский язык быстро, эффективно и с минимальными затратами по времени с помощью метода интервального повторения. 
 
Нажми "Далее", чтобы узнать больше! """,
        reply_markup=builder.as_markup(),
    )
