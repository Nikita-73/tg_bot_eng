from config import *
from aiogram import F
from aiogram import types
from aiogram.utils.keyboard import InlineKeyboardBuilder


@dp.callback_query(F.data.startswith("Greetings_"))
async def callbacks_num(callback: types.CallbackQuery):
    await callback.message.edit_text("\n".join(callback.message.text.splitlines()[:-2]))
    await greeting(callback)


async def greeting(callback: types.CallbackQuery):
    builder = InlineKeyboardBuilder()
    greet_num = (int)(callback.data.split("_")[1]) + 1
    if greet_num < 5:
        builder.add(types.InlineKeyboardButton(text="Далее", callback_data="Greetings_" + str(greet_num)))
        await callback.message.answer(
            greet_texts[greet_num], reply_markup=builder.as_markup()
        )
    else:
        buttons = [
            [
                types.InlineKeyboardButton(text="Месяц", callback_data="Pay_m"),
                types.InlineKeyboardButton(text="Год", callback_data="Pay_y"),
            ],
            [
                types.InlineKeyboardButton(
                    text="НАВСЕГДА", callback_data="Pay_e"
                )
            ],
        ]
        keyboard = types.InlineKeyboardMarkup(inline_keyboard=buttons)
        await callback.message.answer(
            greet_texts[greet_num], reply_markup=keyboard
        )


greet_texts = ["",
    """Почему именно интервальное повторение? 
Этот метод позволяет легче и быстрее запоминать новые слова, повторяя их с определёнными, научно доказанными интервалами. Таким образом, новая информация лучше закрепляется в памяти. 
 
Нажми "Далее", чтобы узнать, как это работает в нашем боте!""",

    """Как работает наш бот? 
💡 Ты получаешь задания на запоминание слов. 
🎯 Наш бот напоминает тебе повторять эти слова через заданные промежутки времени. 
📈 Прогресс и результаты видны сразу! 
 
Нажми "Далее", чтобы узнать, что ты получишь с подпиской!""",

    """Что ты получишь с подпиской? 
1. Наборы слов, изучив которые вы покроете 90% всего английского языка. 
2. Возможность создавать свои наборы слов. 
3. Аналитика твоего прогресса. 
 
Готов начать учиться эффективно? 
Нажми "Далее" для продолжения!""",

    """Подпишись и начни изучение прямо сейчас! 
📅 Ежедневные задания. 
🔔 Уведомления о необходимости повторения. 
🏆 Постоянный рост твоих знаний. 
 
Нажми "Далее", чтобы узнать о наших тарифах!""",

    """Наши тарифы: 
🔹 доступ к боту на месяц - 399 рублей. 
🔹 доступ к боту на год - 3190 рублей. 
🔹 Доступ к боту НАВСЕГДА - 9870. 
 
Выбери свой тариф и начни обучение!""",
]
