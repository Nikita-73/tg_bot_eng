import logging
from aiogram import Bot, Dispatcher

TOKEN = "7481837442:AAEGgOIcMkzvQB1dCjLrVY29HEVKRNkWPHE"

# Включаем логирование, чтобы не пропустить важные сообщения
logging.basicConfig(level=logging.INFO)
# Объект бота
bot = Bot(token=TOKEN)
# Диспетчер
dp = Dispatcher()
